import Cocoa

final class MainWindowController: NSWindowController {
    override func windowDidLoad() {
        super.windowDidLoad()
    }
}
